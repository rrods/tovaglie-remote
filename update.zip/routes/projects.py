from flask import Blueprint, jsonify, request, send_file, current_app
import os
import uuid
import json
import shutil
from datetime import datetime

projects_bp = Blueprint('projects_bp', __name__)

@projects_bp.route('/api/projects', methods=['GET'])
def get_projects():
    project_service = current_app.config['PROJECT_SERVICE']
    return jsonify(project_service.list_projects())

@projects_bp.route('/api/project/create', methods=['POST'])
def create_project():
    project_service = current_app.config['PROJECT_SERVICE']
    thumb_service = current_app.config['THUMBNAIL_SERVICE']

    data = request.json or {}
    title = data.get('title', 'Nuovo Progetto Luce e Gas')
    brand = data.get('brand', '').strip().upper()

    project_id = project_service.create_project(title)
    project_data = project_service.get_project(project_id)

    if brand:
        project_data['brand']['brand'] = brand
        _auto_apply_logo(project_service, project_id, project_data, brand)
        project_service.save_project(project_id, project_data)

    thumb_service.generate_thumbnail(project_id, project_data, force=True)

    return jsonify({"status": "success", "id": project_id})

@projects_bp.route('/api/project/duplicate', methods=['POST'])
def duplicate_project():
    project_service = current_app.config['PROJECT_SERVICE']
    thumb_service = current_app.config['THUMBNAIL_SERVICE']

    data = request.json or {}
    project_id = data.get('id')

    if not project_id:
        return jsonify({"status": "error", "message": "ID progetto mancante"}), 400

    new_id = project_service.duplicate_project(project_id)
    if new_id:
        new_data = project_service.get_project(new_id)
        thumb_service.generate_thumbnail(new_id, new_data, force=True)
        return jsonify({"status": "success", "id": new_id})

    return jsonify({"status": "error", "message": "Impossibile clonare il file sorgente"}), 404

@projects_bp.route('/api/project/rename', methods=['POST'])
def rename_project():
    project_service = current_app.config['PROJECT_SERVICE']
    thumb_service = current_app.config['THUMBNAIL_SERVICE']

    data = request.json or {}
    project_id = data.get('id')
    new_name = data.get('new_name')

    if not project_id or not new_name:
        return jsonify({"status": "error", "message": "Campi obbligatori mancanti"}), 400

    if project_service.rename_project(project_id, new_name):
        updated_data = project_service.get_project(project_id)
        thumb_service.generate_thumbnail(project_id, updated_data, force=True)
        return jsonify({"status": "success"})

    return jsonify({"status": "error", "message": "Progetto non individuato"}), 404

@projects_bp.route('/api/project/delete', methods=['POST'])
def delete_project():
    project_service = current_app.config['PROJECT_SERVICE']

    data = request.json or {}
    project_id = data.get('id')

    if not project_id:
        return jsonify({"status": "error", "message": "ID mancante"}), 400

    # Elimina anche la thumbnail associata
    thumb_service = current_app.config['THUMBNAIL_SERVICE']
    thumb_path = thumb_service._get_thumbnail_path(project_id)
    if os.path.exists(thumb_path):
        os.remove(thumb_path)

    if project_service.delete_project(project_id):
        return jsonify({"status": "success"})

    return jsonify({"status": "error", "message": "Impossibile rimuovere il file"}), 404

def _auto_apply_logo(project_service, project_id, project_data, brand_name, force=False):
    """Cerca un file loghi/<brand_name>.* e lo imposta come logo nel progetto."""
    work_dir = project_service.projects_dir
    loghi_dir = os.path.join(os.path.dirname(work_dir), 'loghi')
    if not os.path.isdir(loghi_dir):
        return None
    for fname in os.listdir(loghi_dir):
        name, ext = os.path.splitext(fname)
        if name.upper() == brand_name.upper() and ext.lower() in ('.png', '.jpg', '.jpeg', '.gif', '.webp'):
            rel_path = os.path.join('loghi', fname)
            brand = project_data.get('brand', {})
            if force or 'logo' not in brand or not brand['logo']:
                brand['logo'] = rel_path
            if force or 'loghi' not in brand or not brand['loghi']:
                brand['loghi'] = [{'path': rel_path}]
            return rel_path
    return None


@projects_bp.route('/api/project/set_brand', methods=['POST'])
def set_brand():
    project_service = current_app.config['PROJECT_SERVICE']
    thumb_service = current_app.config['THUMBNAIL_SERVICE']

    data = request.json or {}
    project_id = data.get('id')
    brand = data.get('brand', '').strip().upper()

    if not project_id or not brand:
        return jsonify({"status": "error", "message": "Parametri non validi"}), 400

    project_data = project_service.get_project(project_id)
    if not project_data:
        return jsonify({"status": "error", "message": "Progetto non trovato"}), 404

    if 'brand' not in project_data:
        project_data['brand'] = {}
    project_data['brand']['brand'] = brand

    brand_obj = project_data.get('brand', {})
    old_title = brand_obj.get('title', '')
    parts = old_title.split(' - ', 1)
    if len(parts) > 1:
        rest_parts = parts[1].split()
        if rest_parts:
            rest_parts[0] = brand
            brand_obj['title'] = parts[0] + ' - ' + ' '.join(rest_parts)

    logo_applied = _auto_apply_logo(project_service, project_id, project_data, brand, force=True)

    project_service.save_project(project_id, project_data)
    thumb_service.generate_thumbnail(project_id, project_data, force=True)

    return jsonify({
        "status": "success",
        "logo_applied": logo_applied is not None,
        "logo_path": logo_applied
    })


@projects_bp.route('/api/project/set_content_type', methods=['POST'])
def set_content_type():
    project_service = current_app.config['PROJECT_SERVICE']
    thumb_service = current_app.config['THUMBNAIL_SERVICE']

    data = request.json or {}
    project_id = data.get('id')
    content_type = data.get('content_type', '').strip().capitalize()

    if not project_id or content_type not in ('Domestico', 'Business', 'Generico'):
        return jsonify({"status": "error", "message": "Parametri non validi"}), 400

    project_data = project_service.get_project(project_id)
    if not project_data:
        return jsonify({"status": "error", "message": "Progetto non trovato"}), 404

    brand = project_data.get('brand', {})
    old_title = brand.get('title', 'Progetto')
    parts = old_title.split(' - ', 1)
    new_title = content_type + (' - ' + parts[1] if len(parts) > 1 else ' - ' + old_title)
    brand['title'] = new_title

    project_service.save_project(project_id, project_data)
    thumb_service.generate_thumbnail(project_id, project_data, force=True)

    return jsonify({"status": "success", "new_title": new_title})


@projects_bp.route('/api/project/thumbnail/<project_id>', methods=['GET'])
def get_thumbnail(project_id):
    thumb_service = current_app.config['THUMBNAIL_SERVICE']
    project_service = current_app.config['PROJECT_SERVICE']

    thumb_path = thumb_service._get_thumbnail_path(project_id)

    if not os.path.exists(thumb_path):
        project_data = project_service.get_project(project_id)
        if project_data:
            thumb_service.generate_thumbnail(project_id, project_data, force=True)
        else:
            return "Immagine non trovata", 404

    return send_file(thumb_path, mimetype='image/png')

@projects_bp.route('/api/project/import_json', methods=['POST'])
def import_json_project():
    project_service = current_app.config['PROJECT_SERVICE']
    thumb_service = current_app.config['THUMBNAIL_SERVICE']

    if 'file' not in request.files:
        return jsonify({"status": "error", "message": "Nessun file inviato"}), 400

    file = request.files['file']
    if file.filename == '':
        return jsonify({"status": "error", "message": "Nessun file selezionato"}), 400

    try:
        data = json.load(file.stream)
    except Exception:
        return jsonify({"status": "error", "message": "File JSON non valido"}), 400

    if not isinstance(data, dict):
        return jsonify({"status": "error", "message": "Il JSON deve contenere un oggetto"}), 400

    project_id = str(uuid.uuid4())
    project_service.save_project(project_id, data)
    thumb_service.generate_thumbnail(project_id, data, force=True)

    return jsonify({"status": "success", "id": project_id})


@projects_bp.route('/api/project/save/<project_id>', methods=['POST'])
def save_project_data(project_id):
    project_service = current_app.config['PROJECT_SERVICE']
    thumb_service = current_app.config['THUMBNAIL_SERVICE']

    data = request.json
    if not data:
        return jsonify({"status": "error", "message": "Payload vuoto"}), 400

    project_service.save_project(project_id, data)
    thumb_service.generate_thumbnail(project_id, data, force=True)

    return jsonify({"status": "success"})


@projects_bp.route('/api/projects/full_data', methods=['GET'])
def get_all_projects_full_data():
    project_service = current_app.config['PROJECT_SERVICE']
    projects_list = project_service.list_projects()
    
    full_data = []
    for p in projects_list:
        project_id = p.get('id')
        if not project_id:
            continue
        data = project_service.get_project(project_id)
        if data:
            full_data.append({
                "id": project_id,
                "name": p.get("title", "Progetto"),
                "title": p.get("title", ""),
                "brand": data.get("brand", {}),
                "offers": data.get("offers", []),
                "brandData": data.get("brand", {}),
                "offersData": data.get("offers", [])
            })
    
    return jsonify(full_data)


# ---- Upload Logo ----
@projects_bp.route('/api/upload_logo', methods=['POST'])
def upload_logo():
    project_service = current_app.config['PROJECT_SERVICE']
    projects_dir = project_service.projects_dir
    loghi_dir = os.path.join(projects_dir, 'loghi')
    os.makedirs(loghi_dir, exist_ok=True)

    if 'file' not in request.files:
        return jsonify({"status": "error", "message": "Nessun file inviato"}), 400

    file = request.files['file']
    if file.filename == '':
        return jsonify({"status": "error", "message": "Nessun file selezionato"}), 400

    ext = os.path.splitext(file.filename)[1] or '.png'
    filename = f"{uuid.uuid4()}{ext}"
    filepath = os.path.join(loghi_dir, filename)
    file.save(filepath)

    return jsonify({"status": "success", "path": f"loghi/{filename}"})


# ---- Serve uploaded files (loghi, etc.) ----
@projects_bp.route('/api/uploads/<path:filename>')
def serve_upload(filename):
    project_service = current_app.config['PROJECT_SERVICE']
    projects_dir = project_service.projects_dir
    filepath = os.path.join(projects_dir, filename)
    if os.path.exists(filepath):
        return send_file(filepath)
    return jsonify({"status": "error", "message": "File non trovato"}), 404


# ---- Preset: list ----
@projects_bp.route('/api/presets', methods=['GET'])
def list_presets():
    project_service = current_app.config['PROJECT_SERVICE']
    presets_dir = os.path.join(project_service.projects_dir, 'presets')
    os.makedirs(presets_dir, exist_ok=True)

    presets = [f for f in os.listdir(presets_dir) if f.endswith('.json')]
    return jsonify({"status": "success", "presets": presets})


# ---- Preset: get one ----
@projects_bp.route('/api/presets/<filename>', methods=['GET'])
def get_preset(filename):
    project_service = current_app.config['PROJECT_SERVICE']
    presets_dir = os.path.join(project_service.projects_dir, 'presets')
    filepath = os.path.join(presets_dir, filename)
    if not os.path.exists(filepath):
        return jsonify({"status": "error", "message": "Preset non trovato"}), 404

    with open(filepath, 'r', encoding='utf-8') as f:
        preset_data = json.load(f)

    return jsonify({"status": "success", "preset_data": preset_data})


# ---- Preset: save (with overwrite support) ----
@projects_bp.route('/api/presets/save', methods=['POST'])
def save_preset():
    project_service = current_app.config['PROJECT_SERVICE']
    presets_dir = os.path.join(project_service.projects_dir, 'presets')
    os.makedirs(presets_dir, exist_ok=True)

    data = request.json or {}
    name = data.get('name', '').strip()
    if not name:
        return jsonify({"status": "error", "message": "Nome preset obbligatorio"}), 400

    preset_data = data.get('data', {})
    overwrite = data.get('overwrite', False)
    filename = f"{name}.json"
    filepath = os.path.join(presets_dir, filename)

    if os.path.exists(filepath) and not overwrite:
        return jsonify({"status": "exists", "message": "Il preset esiste già"}), 409

    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(preset_data, f, ensure_ascii=False, indent=2)

    return jsonify({"status": "success", "filename": filename})


# ---- Preset: rename ----
@projects_bp.route('/api/presets/rename', methods=['POST'])
def rename_preset():
    project_service = current_app.config['PROJECT_SERVICE']
    presets_dir = os.path.join(project_service.projects_dir, 'presets')

    data = request.json or {}
    old_name = data.get('old_name', '').strip().replace('.json', '')
    new_name = data.get('new_name', '').strip()
    if not old_name or not new_name:
        return jsonify({"status": "error", "message": "Nome vecchio e nuovo obbligatori"}), 400

    old_path = os.path.join(presets_dir, f"{old_name}.json")
    new_path = os.path.join(presets_dir, f"{new_name}.json")

    if not os.path.exists(old_path):
        return jsonify({"status": "error", "message": "Preset non trovato"}), 404
    if os.path.exists(new_path):
        return jsonify({"status": "exists", "message": "Il nome esiste già"}), 409

    os.rename(old_path, new_path)
    return jsonify({"status": "success"})


# ---- Preset: delete ----
@projects_bp.route('/api/presets/delete', methods=['POST'])
def delete_preset():
    project_service = current_app.config['PROJECT_SERVICE']
    presets_dir = os.path.join(project_service.projects_dir, 'presets')

    data = request.json or {}
    name = data.get('name', '').strip().replace('.json', '')
    if not name:
        return jsonify({"status": "error", "message": "Nome preset obbligatorio"}), 400

    filepath = os.path.join(presets_dir, f"{name}.json")
    if not os.path.exists(filepath):
        return jsonify({"status": "error", "message": "Preset non trovato"}), 404

    os.remove(filepath)
    return jsonify({"status": "success"})


@projects_bp.route('/api/backup', methods=['POST'])
def create_backup():
    project_service = current_app.config['PROJECT_SERVICE']
    projects_dir = project_service.projects_dir

    timestamp = datetime.now().strftime('%Y-%m-%d_%H%M%S')
    backup_root = os.path.join(os.path.expanduser('~/Desktop'), f'Backup_Tovaglie_{timestamp}')
    os.makedirs(backup_root, exist_ok=True)

    loghi_src = os.path.join(projects_dir, 'loghi')
    loghi_dst = os.path.join(backup_root, 'loghi')
    if os.path.exists(loghi_src):
        shutil.copytree(loghi_src, loghi_dst)

    copied = 0
    for fname in os.listdir(projects_dir):
        if fname.endswith('.json'):
            src = os.path.join(projects_dir, fname)
            dst = os.path.join(backup_root, fname)
            shutil.copy2(src, dst)

            with open(dst, 'r', encoding='utf-8') as f:
                data = json.load(f)

            brand = data.get('brand', {})
            modified = False
            for key in ('logo', 'logo2'):
                val = brand.get(key)
                if val and not val.startswith('data:') and not val.startswith('/') and not val.startswith('file:'):
                    brand[key] = f"loghi/{os.path.basename(val)}"
                    modified = True
            if modified:
                with open(dst, 'w', encoding='utf-8') as f:
                    json.dump(data, f, ensure_ascii=False, indent=2)
            copied += 1

    return jsonify({
        "status": "success",
        "path": backup_root,
        "projects": copied,
        "message": f"Backup creato in {backup_root} ({copied} progetti)"
    })

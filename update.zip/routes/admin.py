import os
import json
import io
import zipfile
import subprocess
import tempfile
import shutil
from datetime import datetime
from flask import Blueprint, render_template, request, jsonify, current_app

admin_bp = Blueprint('admin_bp', __name__)

BASE_DIR = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
REMOTE_FILES_DIR = os.path.join(BASE_DIR, "remote_files")
TEMPLATES_DIR = os.path.join(BASE_DIR, "templates")
STATIC_DIR = os.path.join(BASE_DIR, "static")
REMOTE_CONFIG_FILE = os.path.join(BASE_DIR, "remote_config.json")


def _load_remote_config():
    if os.path.exists(REMOTE_CONFIG_FILE):
        try:
            with open(REMOTE_CONFIG_FILE, "r") as f:
                return json.load(f)
        except Exception:
            pass
    return {}


def _load_version():
    p = os.path.join(BASE_DIR, "version.json")
    if os.path.exists(p):
        try:
            with open(p, "r") as f:
                return json.load(f)
        except Exception:
            pass
    return {"version": "0.0.0", "release_notes": ""}


def _save_version(data):
    with open(os.path.join(BASE_DIR, "version.json"), "w") as f:
        json.dump(data, f, indent=2)
    with open(os.path.join(REMOTE_FILES_DIR, "version.json"), "w") as f:
        json.dump(data, f, indent=2)


def _load_status():
    p = os.path.join(REMOTE_FILES_DIR, "status.json")
    if os.path.exists(p):
        try:
            with open(p, "r") as f:
                return json.load(f)
        except Exception:
            pass
    return {"blocked": False, "message": ""}


def _save_status(data):
    with open(os.path.join(REMOTE_FILES_DIR, "status.json"), "w") as f:
        json.dump(data, f, indent=2)


def _create_update_zip():
    zip_buffer = io.BytesIO()
    with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as zf:
        for root, _, files in os.walk(TEMPLATES_DIR):
            for fn in files:
                fp = os.path.join(root, fn)
                arcname = os.path.relpath(fp, BASE_DIR)
                zf.write(fp, arcname)
        for root, _, files in os.walk(STATIC_DIR):
            for fn in files:
                fp = os.path.join(root, fn)
                arcname = os.path.relpath(fp, BASE_DIR)
                zf.write(fp, arcname)
        vp = os.path.join(BASE_DIR, "version.json")
        if os.path.exists(vp):
            zf.write(vp, "version.json")
    zip_buffer.seek(0)
    return zip_buffer


def _git_push():
    cfg = _load_remote_config()
    repo_url = cfg.get("repo", "")
    if not repo_url:
        return "Repo non configurato in remote_config.json"

    full_url = f"https://github.com/{repo_url}.git"
    tmp_dir = tempfile.mkdtemp(prefix="tovaglie_remote_")

    try:
        result = subprocess.run(
            ["git", "clone", full_url, tmp_dir],
            capture_output=True, text=True, timeout=30
        )
        if result.returncode != 0:
            return f"Errore clone: {result.stderr.strip()}"

        for fn in os.listdir(REMOTE_FILES_DIR):
            src = os.path.join(REMOTE_FILES_DIR, fn)
            if os.path.isfile(src):
                shutil.copy2(src, os.path.join(tmp_dir, fn))

        update_zip_path = os.path.join(tmp_dir, "update.zip")
        with open(update_zip_path, "wb") as f:
            f.write(_create_update_zip().getvalue())

        subprocess.run(["git", "add", "."], cwd=tmp_dir, capture_output=True, timeout=10)
        subprocess.run(
            ["git", "commit", "-m", f"Aggiornamento automatico {datetime.now().strftime('%Y-%m-%d %H:%M')}"],
            cwd=tmp_dir, capture_output=True, timeout=10
        )
        result = subprocess.run(
            ["git", "push"],
            cwd=tmp_dir, capture_output=True, text=True, timeout=30
        )
        if result.returncode != 0:
            return f"Errore push: {result.stderr.strip()}"

        return None
    except subprocess.TimeoutExpired:
        return "Timeout durante l'operazione git"
    except Exception as e:
        return str(e)
    finally:
        shutil.rmtree(tmp_dir, ignore_errors=True)


@admin_bp.route('/admin')
def admin_page():
    ver = _load_version()
    status = _load_status()
    cfg = _load_remote_config()
    return render_template(
        'admin.html',
        version=ver.get("version", "0.0.0"),
        release_notes=ver.get("release_notes", ""),
        blocked=status.get("blocked", False),
        block_message=status.get("message", ""),
        repo=cfg.get("repo", ""),
    )


@admin_bp.route('/api/admin/push_update', methods=['POST'])
def push_update():
    data = request.get_json(silent=True) or {}
    if data.get("confirm") != "confermo":
        return jsonify({"status": "error", "message": "Conferma testuale 'confermo' richiesta"}), 400

    ver = _load_version()
    ver["version"] = data.get("version", ver["version"])
    ver["release_notes"] = data.get("release_notes", ver.get("release_notes", ""))
    _save_version(ver)

    error = _git_push()
    if error:
        return jsonify({"status": "error", "message": error}), 500

    return jsonify({"status": "success", "message": "Update impacchettato e inviato con successo"})


@admin_bp.route('/api/admin/check_remote_status', methods=['GET'])
def check_remote_status():
    import sys
    sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
    import update_checker
    try:
        cfg = update_checker._get_config()
        url = cfg.get("status_url", "")
        if not url:
            return jsonify({"status": "error", "message": "URL remoto non configurato"}), 400
        data = update_checker.fetch_json(url, cache_bust=True)
        if "error" in data:
            return jsonify({"status": "error", "message": "Impossibile contattare GitHub. Verifica la connessione."}), 503
        return jsonify({
            "status": "success",
            "blocked": data.get("blocked", False),
            "message": data.get("message", "")
        })
    except Exception as e:
        return jsonify({"status": "error", "message": f"Errore: {str(e)}"}), 500


@admin_bp.route('/api/admin/set_block', methods=['POST'])
def set_block():
    data = request.get_json(silent=True) or {}
    if data.get("confirm") != "confermo":
        return jsonify({"status": "error", "message": "Conferma testuale 'confermo' richiesta"}), 400

    blocked = data.get("blocked", False)
    message = data.get("message", "")
    _save_status({"blocked": blocked, "message": message})

    error = _git_push()
    if error:
        return jsonify({"status": "error", "message": error}), 500

    return jsonify({"status": "success", "message": "Stato blocco aggiornato e inviato"})


@admin_bp.route('/api/admin/set_version', methods=['POST'])
def set_version():
    data = request.get_json(silent=True) or {}
    if data.get("confirm") != "confermo":
        return jsonify({"status": "error", "message": "Conferma testuale 'confermo' richiesta"}), 400

    new_version = data.get("version", "").strip()
    if not new_version:
        return jsonify({"status": "error", "message": "Versione non valida"}), 400

    notes = data.get("release_notes", "")
    _save_version({"version": new_version, "release_notes": notes, "min_windows_version": "10"})

    return jsonify({
        "status": "success",
        "message": f"Versione aggiornata a {new_version}",
        "version": new_version
    })

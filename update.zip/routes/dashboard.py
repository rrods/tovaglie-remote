from flask import Blueprint, render_template, current_app, redirect, url_for

dashboard_bp = Blueprint('dashboard_bp', __name__)

UPDATE_VERSION = [None]

@dashboard_bp.route('/')
@dashboard_bp.route('/dashboard')
def index():
    ver = UPDATE_VERSION[0]
    return render_template('dashboard.html', update_version=ver)

@dashboard_bp.route('/builder/<project_id>')
def open_builder(project_id):
    if project_id == 'all':
        project_service = current_app.config['PROJECT_SERVICE']
        projects_list = project_service.list_projects()
        full_data = []
        for p in projects_list:
            pid = p.get('id')
            if not pid:
                continue
            data = project_service.get_project(pid)
            if data:
                full_data.append({
                    "id": pid,
                    "name": p.get("title", "Progetto"),
                    "title": p.get("title", ""),
                    "brand": data.get("brand", {}),
                    "offers": data.get("offers", []),
                    "brandData": data.get("brand", {}),
                    "offersData": data.get("offers", [])
                })
        return render_template('builder.html', project_id='all', project_data={"all_projects": full_data})

    project_service = current_app.config['PROJECT_SERVICE']
    project_data = project_service.get_project(project_id)
    if not project_data:
        return redirect(url_for('dashboard_bp.index'))

    return render_template('builder.html', project_id=project_id, project_data=project_data)
